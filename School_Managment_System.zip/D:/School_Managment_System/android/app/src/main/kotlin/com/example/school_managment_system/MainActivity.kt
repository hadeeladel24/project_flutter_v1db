package com.example.school_managment_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
