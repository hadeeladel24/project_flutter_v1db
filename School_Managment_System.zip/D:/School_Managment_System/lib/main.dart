import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'نظام إدارة المعلمين',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const AddTeacherScreen(),
    );
  }
}

class AddTeacherScreen extends StatefulWidget {
  const AddTeacherScreen({super.key});

  @override
  State<AddTeacherScreen> createState() => _AddTeacherScreenState();
}

class _AddTeacherScreenState extends State<AddTeacherScreen> {
  final _formKey = GlobalKey<FormState>();
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _specializationController = TextEditingController();
  final _emailController = TextEditingController();
  final _addressController = TextEditingController();
  final _phoneController = TextEditingController();
  final _salaryController = TextEditingController();
  final _birthDateController = TextEditingController();
  String _gender = 'male';
  bool _isLoading = false;

  final _dbRef = FirebaseDatabase.instance.ref().child('teachers');

  Future<void> _saveTeacher() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final newTeacherRef = _dbRef.push();

      await newTeacherRef.set({
        'teacher_id': newTeacherRef.key,
        'first_name': _firstNameController.text,
        'last_name': _lastNameController.text,
        'specialization': _specializationController.text,
        'email': _emailController.text,
        'address': _addressController.text,
        'phone_number': int.tryParse(_phoneController.text) ?? 0,
        'salary': int.tryParse(_salaryController.text) ?? 0,
        'birth_date': _birthDateController.text,
        'gender': _gender,
        'created_at': ServerValue.timestamp,
      });

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تمت إضافة المعلم بنجاح')),
      );

      // مسح الحقول بعد الإضافة
      _firstNameController.clear();
      _lastNameController.clear();
      _specializationController.clear();
      _emailController.clear();
      _addressController.clear();
      _phoneController.clear();
      _salaryController.clear();
      _birthDateController.clear();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('حدث خطأ: ${e.toString()}')),
      );
      debugPrint('Error saving teacher: $e');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    _specializationController.dispose();
    _emailController.dispose();
    _addressController.dispose();
    _phoneController.dispose();
    _salaryController.dispose();
    _birthDateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة معلم جديد')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _firstNameController,
                decoration: const InputDecoration(labelText: 'الاسم الأول'),
                validator: (value) => value!.isEmpty ? 'مطلوب' : null,
              ),
              TextFormField(
                controller: _lastNameController,
                decoration: const InputDecoration(labelText: 'اسم العائلة'),
                validator: (value) => value!.isEmpty ? 'مطلوب' : null,
              ),
              TextFormField(
                controller: _specializationController,
                decoration: const InputDecoration(labelText: 'التخصص'),
                validator: (value) => value!.isEmpty ? 'مطلوب' : null,
              ),
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(labelText: 'البريد الإلكتروني'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'مطلوب';
                  }
                  if (!value.contains('@')) {
                    return 'بريد إلكتروني غير صالح';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _addressController,
                decoration: const InputDecoration(labelText: 'العنوان'),
                validator: (value) => value!.isEmpty ? 'مطلوب' : null,
              ),
              TextFormField(
                controller: _phoneController,
                decoration: const InputDecoration(labelText: 'رقم الهاتف'),
                keyboardType: TextInputType.phone,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'مطلوب';
                  }
                  if (int.tryParse(value) == null) {
                    return 'يجب أن يكون رقماً فقط';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _salaryController,
                decoration: const InputDecoration(labelText: 'الراتب'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'مطلوب';
                  }
                  if (int.tryParse(value) == null) {
                    return 'يجب أن يكون رقماً فقط';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _birthDateController,
                decoration: const InputDecoration(labelText: 'تاريخ الميلاد (يوم-شهر-سنة)'),
                validator: (value) => value!.isEmpty ? 'مطلوب' : null,
              ),
              DropdownButtonFormField<String>(
                value: _gender,
                decoration: const InputDecoration(labelText: 'الجنس'),
                items: ['male', 'female'].map((g) => DropdownMenuItem(
                  value: g,
                  child: Text(g == 'male' ? 'ذكر' : 'أنثى'),
                )).toList(),
                onChanged: (value) => setState(() => _gender = value!),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _isLoading ? null : _saveTeacher,
                child: _isLoading
                    ? const CircularProgressIndicator()
                    : const Text('حفظ المعلم'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}